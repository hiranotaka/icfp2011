#!/bin/sh
~/ltg.linux64 -silent true match ./run ../run
