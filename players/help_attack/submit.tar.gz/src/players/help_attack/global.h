#ifndef GLOBAL_H
#define GLOBAL_H

extern struct game* G;
extern bool DEBUG;
extern int SLEEP_TIME;
extern int MY_PLAYER;
extern int OPP_PLAYER;

#endif

